IPP 1. projekt
==============

###Requirements:

PHP5.6, composer, bash, git


###Initialization commands

```
$ cd /project/root/
$ composer dump-autoload
```

###Create archive command

```
$ cd /project/root/
$ bash create_archive
```

###Test archive command

```
$ cd /project/root/
$ bash test_archive
```